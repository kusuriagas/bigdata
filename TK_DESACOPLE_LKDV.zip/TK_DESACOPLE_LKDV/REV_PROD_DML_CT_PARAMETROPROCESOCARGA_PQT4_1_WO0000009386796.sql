-- ************************************************************************************************************************************
-- || PROYECTO       : BCP - Evolucion Data Lake
-- || NOMBRE         : REV_PROD_DML_CT_PARAMETROPROCESOCARGA_PQT4_1.sql
-- || TABLA DESTINO  : ADMIN.CT_PARAMETROPROCESOCARGA_LHCL
-- || TABLAS FUENTES : DML
-- || OBJETIVO       : REVERTIR TABLA ADMIN.CT_PARAMETROPROCESOCARGA_LHCL
-- || TIPO           : SQL
-- || REPROCESABLE   : NA
-- || OBSERVACION    : NA
-- || SCHEDULER      : NA
-- || JOB            : NA
-- || ----------------------------------------------------------------------------------------------------------
-- || VERSION     DESARROLLADOR        PROVEEDOR               PO                   FECHA             DESCRIPCION
-- || ----------------------------------------------------------------------------------------------------------
-- || 1           BRYAN RODRIGUEZ      INDRA             LILY LUJAN AYQUIPA         19/06/2024       Creacion de Script 
-- *************************************************************************************************************

---------------------------------------------------------------------------------------------------------------------------------------------------------------
--PARAMETROS DE CARGA A LA TABLA CT_PARAMETROPROCESOCARGA_LHCL
---------------------------------------------------------------------------------------------------------------------------------------------------------------
SET ECHO ON;
SET TIMING ON;

WHENEVER SQLERROR EXIT 1;

DELETE FROM ADMIN.CT_PARAMETROPROCESOCARGA_LHCL WHERE DESPROCESOCARGA = 'HALL_TEMP_HD_BASEENCUESTAEXPERIENCIACLIENTECLS' AND DESMODULOPROCESOCARGA = 'CDDV' AND CODPARAMETRO='PRM_ENABLE_CONVIVENCIA';
COMMIT;
INSERT INTO ADMIN.CT_PARAMETROPROCESOCARGA_LHCL (DESPROCESOCARGA, DESMODULOPROCESOCARGA, NUMSECUENCIAEJECUCION, CODPARAMETRO, DESVALORPARAMETRO) VALUES ('HALL_TEMP_HD_BASEENCUESTAEXPERIENCIACLIENTECLS','CDDV',1,'PRM_ENABLE_CONVIVENCIA','0');
COMMIT;

DISCONNECT;
EXIT;
