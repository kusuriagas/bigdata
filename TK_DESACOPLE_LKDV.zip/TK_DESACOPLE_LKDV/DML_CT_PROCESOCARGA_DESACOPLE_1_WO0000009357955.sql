-- ************************************************************************************************************************************
-- || PROYECTO       : BCP - Evolucion Data Lake
-- || NOMBRE         : DML_CT_PROCESOCARGA_DESACOPLE_1.sql
-- || TABLA DESTINO  : ADMIN.CT_PROCESOCARGA_LHCL
-- || TABLAS FUENTES : DML
-- || OBJETIVO       : POBLAR TABLA ADMIN.CT_PROCESOCARGA_LHCL
-- || TIPO           : SQL
-- || REPROCESABLE   : NA
-- || OBSERVACION    : NA
-- || SCHEDULER      : NA
-- || JOB            : NA
-- || ----------------------------------------------------------------------------------------------------------
-- || VERSION     DESARROLLADOR        PROVEEDOR               PO                   FECHA             DESCRIPCION
-- || ----------------------------------------------------------------------------------------------------------
-- || 1           BRYAN RODRIGUEZ      INDRA                   RAUL IZQUIERDO       04/06/2024       Creacion de Script 
-- *************************************************************************************************************

---------------------------------------------------------------------------------------------------------------------------------------------------------------
--PARAMETROS DE CARGA A LA TABLA CT_PROCESOCARGA_LHCL
---------------------------------------------------------------------------------------------------------------------------------------------------------------

SET ECHO ON;
SET TIMING ON;

WHENEVER SQLERROR EXIT 1;

UPDATE ADMIN.CT_PROCESOCARGA_LHCL SET TIPTECNOLOGIACARGA='ADB' WHERE DESPROCESOCARGA = 'DTI_CONEXIONKAFKACMCC' AND DESMODULOPROCESOCARGA = 'CALI';
COMMIT;

UPDATE ADMIN.CT_PROCESOCARGA_LHCL SET TIPTECNOLOGIACARGA='ADB' WHERE DESPROCESOCARGA = 'DTI_CONEXIONKAFKACMCC' AND DESMODULOPROCESOCARGA = 'CRDV';
COMMIT;

UPDATE ADMIN.CT_PROCESOCARGA_LHCL SET TIPTECNOLOGIACARGA='ADB' WHERE DESPROCESOCARGA = 'CRMO_CSRE_CASEDELTA_LHCL' AND DESMODULOPROCESOCARGA = 'CRDV';
COMMIT;

UPDATE ADMIN.CT_PROCESOCARGA_LHCL SET TIPTECNOLOGIACARGA='ADB' WHERE DESPROCESOCARGA = 'CRMO_CSRE_ACCOUNTDELTA_LHCL' AND DESMODULOPROCESOCARGA = 'CRDV';
COMMIT;

DISCONNECT;
EXIT;
