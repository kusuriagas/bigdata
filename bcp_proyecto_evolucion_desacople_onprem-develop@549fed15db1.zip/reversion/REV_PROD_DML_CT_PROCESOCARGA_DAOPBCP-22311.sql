-- ************************************************************************************************************************************
-- || PROYECTO       : BCP - Evolucion Data Lake
-- || NOMBRE         : REV_PROD_DML_CT_PROCESOCARGA_DAOPBCP-22311.sql
-- || TABLA DESTINO  : ADMIN.CT_PROCESOCARGA_LHCL
-- || TABLAS FUENTES : DML
-- || OBJETIVO       : REVERTIR TABLA ADMIN.CT_PROCESOCARGA_LHCL
-- || TIPO           : SQL
-- || REPROCESABLE   : NA
-- || OBSERVACION    : NA
-- || SCHEDULER      : NA
-- || JOB            : NA
-- || ----------------------------------------------------------------------------------------------------------
-- || VERSION     DESARROLLADOR        PROVEEDOR               PO                   FECHA             DESCRIPCION
-- || ----------------------------------------------------------------------------------------------------------
-- || 1           BRYAN RODRIGUEZ       INDRA             LILY LUJAN AYQUIPA         04/06/2024       Creacion de Script 
-- *************************************************************************************************************

---------------------------------------------------------------------------------------------------------------------------------------------------------------
--PARAMETROS DE CARGA A LA TABLA CT_PROCESOCARGA_LHCL
---------------------------------------------------------------------------------------------------------------------------------------------------------------


SET ECHO ON;
SET TIMING ON;

WHENEVER SQLERROR EXIT 1;

DELETE FROM ADMIN.CT_PROCESOCARGA_LHCL WHERE DESPROCESOCARGA = 'CAMB_XR_MOVNMON_PRECIOTC' AND DESMODULOPROCESOCARGA = 'CRDV';
DELETE FROM ADMIN.CT_PROCESOCARGA_LHCL WHERE DESPROCESOCARGA = 'CRMO_SCRM_APEXTRIGGER' AND DESMODULOPROCESOCARGA = 'CRDV';
DELETE FROM ADMIN.CT_PROCESOCARGA_LHCL WHERE DESPROCESOCARGA = 'CRMO_SCRM_CONTENTDOCUMENTLINK' AND DESMODULOPROCESOCARGA = 'CRDV';
DELETE FROM ADMIN.CT_PROCESOCARGA_LHCL WHERE DESPROCESOCARGA = 'CRMO_SCRM_LIGHTNINGPERFORMANCE' AND DESMODULOPROCESOCARGA = 'CRDV';
DELETE FROM ADMIN.CT_PROCESOCARGA_LHCL WHERE DESPROCESOCARGA = 'CRMO_SCRM_LOGINHISTORY' AND DESMODULOPROCESOCARGA = 'CRDV';
DELETE FROM ADMIN.CT_PROCESOCARGA_LHCL WHERE DESPROCESOCARGA = 'CRMO_SCRM_QUEUEDEXECUTION' AND DESMODULOPROCESOCARGA = 'CRDV';
DELETE FROM ADMIN.CT_PROCESOCARGA_LHCL WHERE DESPROCESOCARGA = 'CRMO_SCRM_VISUALFORCE' AND DESMODULOPROCESOCARGA = 'CRDV';
DELETE FROM ADMIN.CT_PROCESOCARGA_LHCL WHERE DESPROCESOCARGA = 'F951_TIPOCAMBIOOTRASMONEDAS' AND DESMODULOPROCESOCARGA = 'CRDV';
COMMIT;

DISCONNECT;
EXIT;