 # 📚 Repositorio BCP_PROYECTO_EVOLUCION_DESACOPLE_ONPREM 📚



## 📘 Descripción general

* Repositorio que cuenta con DML para desacople de procesos on-premise.



## 📙 DATAOPS  (De más reciente a más antiguo)
* DAOPBCP-22311 - [LHCL][DDV][DML_DUMMY] - Desacople de procesos on-premise - Bloque 1
* DAOPBCP-22118 - [LHCL][DDV][DML_DUMMY] - Desacople de procesos on-premise - Bloque 0


## 📗 Información ️

|                                                                              ||          ||               ||
|------------------------------------------------------------------------------| -------- |----------| -------- |---------------|  -------- |
| **PROCESO**                                                                  | **DESCRIPCION** | **JOB**  | **SQUAD** | **PO**        | **RELEASE** |
| N/A | Desacople de procesos on-premise - Bloque 0 | N/A | MIGRACION | Raul Izquierdo | release/DAOPBCP-22118
| N/A | Desacople de procesos on-premise - Bloque 1 | N/A | MIGRACION | Raul Izquierdo | release/DAOPBCP-22311

